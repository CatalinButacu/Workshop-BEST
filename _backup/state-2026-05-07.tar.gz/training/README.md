# Training Web — BEST Iași

Materiale pentru un training de 2 ore de programare web pentru începători. Audiența: studenți BEST Iași — voluntariat de mentorat student-la-student.

> **🚀 Pentru trainer:** [TRAINER_GUIDE.md](TRAINER_GUIDE.md) — schemă minute-cu-minute pentru sesiunea 20:00–22:00.

## Structura

```
training/
├── README.md
├── TRAINER_GUIDE.md
├── build.sh / build.bat        # compilare PDF-uri
├── src/                        # surse LaTeX
│   ├── preamble.tex
│   ├── 00-inainte.tex          # 1 pagină — pre-rechizite, trimis cu 24h înainte
│   └── codex.tex               # Coteț Codex — 6 faze, ~14 pagini referință
├── pdf/                        # output compilat
│   ├── 00-inainte.pdf
│   └── codex.pdf
├── slides/
│   └── index.html              # Reveal.js, dark theme, single-file
└── kit-starter/                # 3 demo-uri practice
    ├── README.md
    ├── 00-blank/               # canvas gol pentru a porni de la 0
    ├── 01-broken/              # site cu 10 probleme — exercițiu Lighthouse
    └── 02-reference/           # site complet, best practices aplicate
```

## Cele 4 deliverabile

| Artefact | Format | Rol |
|---|---|---|
| `00-inainte.pdf` | PDF, 1 pagină | Trimis cu 24h înainte. Setup VS Code + Live Server + Git + GitHub. |
| `codex.pdf` | PDF, ~14 pagini | **Coteț Codex** — referința echipei IT. 6 faze, cod adnotat, capcane. |
| `slides/index.html` | Reveal.js, dark theme | Prezentarea de la fața locului, 30 slide-uri. |
| `kit-starter/` | Folder cu 3 demo-uri | Practică hands-on: schelet gol, site rupt pentru audit, site complet. |

## Compilare PDF-uri

Din rădăcina `training/`, în Git Bash:

```bash
./build.sh                # compilează tot
./build.sh codex          # compilează doar codex.tex
```

Pe Windows, dublu-click pe `build.bat`.

## Cele 6 faze (codex + slides)

| Fază | Concept-cheie |
|---|---|
| §1 HTML | Semantic + viewport meta + a11y baseline |
| §2 CSS | Custom properties + flex + mobile-first + light-dark() |
| §3 JS | Pattern `select → listen → change` |
| §4 Deploy | git push → GitHub Pages → URL public |
| §5 Metadata/SEO | title, description, og:image **absolute** |
| §6 Lighthouse | Audit profesional, target 95+/100 |

## Cerințe pentru build

- **MiKTeX** sau **TeX Live** (pentru `pdflatex`)
- Pe Windows: **Git for Windows** (pentru `bash`)
- Pachete LaTeX (toate standard, MiKTeX le auto-instalează): `babel`, `geometry`, `xcolor`, `listings`, `hyperref`, `enumitem`, `titlesec`, `fancyhdr`, `parskip`, `tcolorbox`, `tikz`, `fontawesome5`, `lato`/`tgheros`

## Distribuție către participanți

- **T-1 zi:** trimite `pdf/00-inainte.pdf` în Discord/Slack
- **În timpul training-ului:** `pdf/codex.pdf` deschis pe ecranele lor + `kit-starter/` ca repository fork-abil
- **După training:** lasă tot (Codex + kit-starter) ca referință permanentă pentru concurs și proiecte personale

## Filozofie

Cele 2h nu sunt despre **cantitate** de concepte. Sunt despre **calitate** pe puține lucruri + **muscle memory** pe ciclul de deploy + **standard măsurabil** prin Lighthouse.

Fiecare concept din slides și codex e ancorat într-un exemplu concret din `kit-starter/02-reference/` — zero teorie suspendată.
