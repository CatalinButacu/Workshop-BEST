@echo off
REM Wrapper Windows pentru build.sh — necesita Git for Windows (Git Bash) instalat.
bash build.sh %*
pause
