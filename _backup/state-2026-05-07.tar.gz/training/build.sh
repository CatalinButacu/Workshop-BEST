#!/usr/bin/env bash
#
# build.sh — Compile training PDFs.
#
# - Reads .tex from src/, outputs .pdf to pdf/
# - Cleans up auxiliary files
# - Runs pdflatex twice for cross-references
#
# Usage:   ./build.sh           (compile everything)
#          ./build.sh codex     (compile a single file)
#
# Requires: pdflatex (MiKTeX or TeX Live) on PATH.

set -e
set -u

SRC_DIR="src"
OUT_DIR="pdf"

FILES=(
  00-inainte
  codex
)

if [ "$#" -gt 0 ]; then
  FILES=("$1")
fi

if ! command -v pdflatex >/dev/null 2>&1; then
  echo "ERROR: pdflatex not found on PATH. Install MiKTeX or TeX Live."
  exit 1
fi

if [ ! -d "$SRC_DIR" ]; then
  echo "ERROR: source folder '$SRC_DIR' not found. Run from training/ root."
  exit 1
fi

mkdir -p "$OUT_DIR"

START_TIME=$(date +%s)
TOTAL=${#FILES[@]}
COUNT=0
FAILED=()

pushd "$SRC_DIR" > /dev/null

for f in "${FILES[@]}"; do
  COUNT=$((COUNT + 1))
  if [ ! -f "$f.tex" ]; then
    echo "[$COUNT/$TOTAL] SKIP $f.tex (not found)"
    continue
  fi
  echo "[$COUNT/$TOTAL] Compiling $f.tex ..."
  if pdflatex -interaction=nonstopmode -halt-on-error "$f.tex" > /dev/null 2>&1 \
  && pdflatex -interaction=nonstopmode -halt-on-error "$f.tex" > /dev/null 2>&1; then
    mv -f "$f.pdf" "../$OUT_DIR/"
    echo "        -> $OUT_DIR/$f.pdf"
  else
    echo "        FAILED — see $f.log for details"
    FAILED+=("$f")
  fi
done

rm -f *.aux *.out *.toc *.synctex.gz

if [ "${#FAILED[@]}" -eq 0 ]; then
  rm -f *.log
fi

popd > /dev/null

ELAPSED=$(( $(date +%s) - START_TIME ))

echo ""
echo "========================================"
if [ "${#FAILED[@]}" -eq 0 ]; then
  echo "Build complete in ${ELAPSED}s. PDFs in $OUT_DIR/"
  ls -la "$OUT_DIR"/*.pdf 2>/dev/null | awk '{printf "  %s  %s\n", $5, $NF}'
else
  echo "Build finished with ${#FAILED[@]} failure(s) in ${ELAPSED}s."
  for f in "${FAILED[@]}"; do
    echo "  - $f"
  done
  exit 1
fi
