# Trainer Guide — Training Web BEST Iași

**Sesiune:** 20:00 – 22:00 (cu posibilă extensie 30 min).
**Format:** on-site, ~17 participanți, 4–5 cu ceva experiență, restul beginneri.
**Goal:** la 22:00 fiecare participant are un site live pe URL public + Lighthouse 90+ + materiale ca să continue singur.

---

## Înainte de training

### Cu 24h înainte

- Trimite `pdf/00-inainte.pdf` în grupul Discord/Slack.
- Distribuie folderul `kit-starter/` (zip sau repo Git) — opțional, pentru cine vrea să se uite înainte.
- Postează mesajul de mai jos.

```
Sal omuleți, mâine ne vedem la 20:00 pentru training-ul de web dev.

📎 Atașat: PDF de 1 pagină cu lucrurile pe care vă rog să le verificați
ÎNAINTE de training. Durează ~5 minute.

Pe scurt aveți de:
  1. VS Code + extensia Live Server
  2. Git (din training-ul de Git, deja instalat)
  3. Cont GitHub

⚠️ Vă rog faceți astea AZI, nu mâine la 19:55. Dacă ceva nu merge,
dați de mine acum.

Aduceți cu voi:
  - Laptop + încărcător
  - O idee de site dacă aveți (portofoliu, blog, glume BEST...)
  - Răbdare. Promit că la 22:00 fiecare are URL-ul lui.

Pe mâine! 🚀
```

### În ziua training-ului

- **Adu cu tine:**
  - Laptop-ul tău cu setup-ul ready + slides-urile deschise în browser
  - **USB stick** cu installerele (VS Code, Git) ca backup
  - **Hotspot** pe telefon ca backup pentru Wi-Fi
  - `pdf/codex.pdf` printat sau pe laptop
- **Pre-brief cei 3 avansați** (5 min înainte): *"Voi sunteți deja peste medie. Dacă vedeți pe cineva blocat, ajutați. E cel mai bun mod să consolidați."*
- **Verifică sala:** prize, proiector, internet.

---

## Schema sesiunii (2h, 6 faze)

| Slot | Durată | Fază | Slide § | Codex § | Demo |
|---|---|---|---|---|---|
| 20:00–20:08 | 8 min | Welcome + demo + 3 straturi | Intro | — | `02-reference` |
| 20:08–20:30 | 22 min | **§1 HTML** | Faza 1 | §1 | `02-reference/index.html` |
| 20:30–20:55 | 25 min | **§2 CSS** | Faza 2 | §2 | `02-reference/style.css` |
| 20:55–21:00 | 5 min | ☕ Pauză | — | — | — |
| 21:00–21:18 | 18 min | **§3 JS** | Faza 3 | §3 | `02-reference/script.js` |
| 21:18–21:33 | 15 min | **§4 Deploy** | Faza 4 | §4 | live: git push pe site-ul lor |
| 21:33–21:45 | 12 min | **§5 Metadata/SEO** | Faza 5 | §5 | live: opengraph.xyz |
| 21:45–21:57 | 12 min | **§6 Lighthouse** | Faza 6 | §6 | live: Lighthouse pe `01-broken` |
| 21:57–22:00 | 3 min | Wrap | Outro | Resurse | — |

**Total: 120 min, exact.**

---

## Block 1 — Welcome (20:00 – 20:08)

**Obiectiv:** energie + claritate + a vedea destinația.

- Deschide slide-urile (slide 1–3).
- **Arată un site finit** — `kit-starter/02-reference/` rulat local cu Live Server, sau deja deployat.
- Click prin el. Apoi **deschide source code-ul în VS Code lângă**.
- *"Codul de pe stânga e ce vom scrie împreună. Mai puțin decât pare. La 22:00, fiecare are unul ca ăsta pe URL real."*
- **Energy check:** *"câți nu ați scris niciodată cod de website?"* — confirmă bara.

---

## Block 2 — §1 HTML (20:08 – 20:30)

**Obiectiv:** fiecare are scheletul HTML al paginii sale, cu toate metadata-urile must-have.

**Slide-uri:** Faza 1 intro → Anatomia minima → 3 must-have head → Semantic vs div soup → Heading hierarchy → Form labels.

**Live coding:**
1. Deschide `kit-starter/00-blank/index.html` (sau ei creează de la 0 dacă au timp).
2. Adaugă semantic structure: `<header>`, `<main>`, `<section>`, `<footer>`.
3. Hero, Despre, Contact form.
4. **Single h1, h2 per secțiune.**
5. Form cu `<label for>` + `<input id>` perechi.

**Reference:** la sfârșitul blocului, deschide `kit-starter/02-reference/index.html` — *"asta-i destinația. Scroll prin tags, vezi cum se mapează."*

---

## Block 3 — §2 CSS (20:30 – 20:55)

**Obiectiv:** site-ul lor arată stylish, responsive, cu dark mode.

**Slide-uri:** Faza 2 intro → Variables → Reset → Flex → Mobile-first → Bonus light-dark().

**Live coding:**
1. Adaugă `:root` cu variabilele din slide.
2. Paste reset (5 linii).
3. Header cu flex (logo stânga, nav dreapta).
4. Hero centrat cu `text-align: center` + `padding`.
5. Media query `min-width: 768px` pentru desktop nav.
6. **Wow moment:** adaugă `light-dark()` + `color-scheme` → schimbă theme-ul OS-ului → site-ul se rebrandează automat.

> 💡 **Senior tip pe slide:** "Schimbi `--primary` în 1 linie → tot site-ul. Asta e magia variabilelor."

---

## 🔄 Pauză (20:55 – 21:00, 5 min)

- Apă, baie, social.
- **Tu:** verifică că Wi-Fi-ul ține pentru deploy. Cele mai mari probleme apar la `git push`.

---

## Block 4 — §3 JS (21:00 – 21:18)

**Obiectiv:** ei să nu se sperie de JS și să aibă hamburger funcțional.

**Slide-uri:** Faza 3 intro → Pattern select-listen-change → const/let/var → Capcana querySelector vs querySelectorAll.

**Live coding:**
1. **Pattern-ul în 3 linii** — buton care schimbă text. Toți scriu împreună.
2. Hamburger toggle: click pe `.nav-toggle` → toggle classă `open` pe `.nav`.
3. Smooth scroll pentru link-urile cu ancoră.
4. (Bonus dacă rămâne timp): form submit handler cu alert.

> 💡 **Senior tip:** "80% din JS pe site-uri statice e select-listen-change. Frameworks (React, Vue) abstractizează asta. Dacă înțelegi pattern-ul vanilla, înțelegi ce face React în spate."

---

## Block 5 — §4 Deploy (21:18 – 21:33)

**Obiectiv:** **fiecare are URL public.** Asta e momentul-cheie al training-ului.

**Slide-uri:** Faza 4 intro → Git workflow → Pages click-by-click → Capcanele.

**Live coding (live-along, încet):**
1. `git init -b main` în Git Bash, în folderul lor.
2. `git add .` + `git commit -m "Initial commit"`.
3. Creează repo public pe GitHub (numele = ce vor ei). **Fără** README/gitignore.
4. `git remote add origin <URL>` + `git push -u origin main`.
5. Settings → Pages → branch `main` → Save.
6. **Așteaptă 30-60 sec, refresh.** URL apare în cutie verde.
7. **Toți pun URL-urile în chat-ul Discord.**
8. *"Trimite-l pe WhatsApp la cineva. Acela e momentul."*

**Backup în caz de probleme:**
- Pe USB ai un repo cu fișierele finale, ready de push, ca rescue
- Hotspot-ul tău ca rezervă internet
- Pentru PAT (Personal Access Token), vezi capcanele din Codex §4

---

## Block 6 — §5 Metadata/SEO (21:33 – 21:45)

**Obiectiv:** site-ul lor arată bine când e share-uit pe WhatsApp.

**Slide-uri:** Faza 5 intro → Title + description → Open Graph → Capcana absolute URL.

**Live coding:**
1. Adaugă `<title>` specific + `<meta description>`.
2. Adaugă cele 5 og tags cu **URL-ul lor de Pages absolut**.
3. *(Optional)* favicon.io → litera lor → drag în repo.
4. Push.
5. Deschide pe `https://opengraph.xyz` cu URL-ul lor → *"uite, link-ul tău arată acum frumos pe WhatsApp."*

---

## Block 7 — §6 Lighthouse (21:45 – 21:57)

**Obiectiv:** ei să simtă că tot ce-au făcut e *măsurabil* și să vadă cum identifică probleme.

**Slide-uri:** Faza 6 intro → 4 categorii → Demo audit pe broken.

**Live exercise:**
1. **(2 min)** Toți rulează Lighthouse pe site-ul **lor** proaspăt deployat → scor așteptat 90+. Validare a tot ce-au făcut.
2. **(5 min)** Deschid `kit-starter/01-broken/` în Live Server → Lighthouse → scor ~50.
3. **(4 min)** Citesc raportul împreună. **Fixează 2 probleme cu ei** (de obicei title + alt). Re-run. Scor urcă la ~75.
4. **(1 min)** *"Restul fix-urilor le faceți acasă. Lista celor 10 probleme e în `01-broken/README.md`. Targetul: 95+ pe toate 4."*

> 💡 **Senior tip:** "La code review în firmă, primul lucru pe care-l fac e să rulez Lighthouse. Sub 90 = înapoi pe board. 95+ e standardul."

---

## Block 8 — Wrap (21:57 – 22:00)

**Obiectiv:** ei pleacă cu sentimentul "pot face asta singur" + au pe cine să întrebe.

- Slide *"Ce ai acum"* — listă concretă.
- *"Aveți: site live, Coteț Codex, kit-starter cu 3 demo-uri, link-uri către MDN/Odin/web.dev."*
- *"Concursul vine în [data]. Diferența între voi azi și voi în 2 săptămâni e doar practica."*
- **Easter egg:** ultimul slide spune *"Slide-urile astea sunt și ele HTML/CSS/JS. View Source. Acum știți tot."*
- Mulțumiri.

---

## Energy management

- **Sala se aglomereze la 21:00.** După 50 min de cod, atenția scade.
- **Pauza la 20:55** vine după CSS (sentiment de progres) și înainte de JS (subiect mai greu).
- **Deploy-ul la 21:18-21:33** = dopamine peak. Folosește-l să relansezi atenția.
- **Lighthouse la 21:45+** = închidere puternică. Lasă-i cu sentimentul "am construit ceva profesional".
- **Vorbește mai tare după 21:00.** Plimbă-te. Privire directă.

---

## Când cineva pică în spate

- **Pre-emptiv:** trio-ul brifat (vezi pre-training).
- **Backup files:** pe USB ai `kit-starter/02-reference/` zip-uit. Dacă cineva e cu 15 min în spate, dă-le să copieze și să continue de acolo.
- **Nu opri grupul.** Lasă cei 1-2 rămași în urmă să recupereze cu ajutor 1-1.

## Când ceva pică în direct

| Eroare | Soluție rapidă |
|---|---|
| VS Code nu e instalat | StackBlitz / CodeSandbox.io ca backup web-only |
| Live Server nu pornește | Dublu-click pe `index.html` (deschide în browser direct, refresh manual cu F5) |
| `git push` cere parolă | Personal Access Token (vezi Codex §4) |
| GitHub Pages 404 | Așteaptă 60s, hard refresh, verifică `index.html` lowercase |
| Wi-Fi pică | Hotspot |
| Proiector pică | Toți pe ecranele lor + tu vorbești mai tare |
| Lighthouse nu rulează | Deschide pagina în Chrome (alt browser nu suportă) |

---

## Ce înseamnă "succes" la 22:00

| Nivel | Definiție |
|---|---|
| **Minimum** | Toți au `index.html` styled și funcțional pe local + au înțeles 6 fazele |
| **Target** | 75%+ au URL public pe GitHub Pages + Lighthouse 90+ |
| **Stretch** | Cineva a făcut deja Lighthouse audit + fix pe `01-broken/` |

Indiferent unde ajung, **toți pleacă cu materialele complete** (Codex + kit-starter + slides).

---

## După training

- **Postează în grup** un mesaj cu URL-urile celor care le-au făcut publice → social proof.
- **La 3 zile distanță:** întreabă cine se mai joacă cu site-ul, cine are întrebări.
- **La concurs:** asigură-te că au repo-ul `kit-starter` ca template.

---

## Note pentru tine ca trainer

- **Nu predai facultate.** Ești coleg care arată o mecanică. Tonul: relaxat, glumeț, încurajator.
- **Greșelile sunt material didactic.** Dacă ai un typo, nu-l ascunzi — îl arăți cum îl găsești în DevTools.
- **Nu acoperi tot.** Acoperi *destul* ca ei să poată continua. Codex + kit-starter fac restul.
- **Mentor energy:** "💡 Senior dev says..." callouts în slide-uri sunt anchor-ul tău. La fiecare apariție, rostește-le natural — *"în producție, ce se face e..."*. Asta dă feeling-ul de mentor↔intern fără să forțezi tema.
- **BEST Iași long game:** peste 1-2 ani, ei să țină training-ul ăsta pentru noua generație. **Lasă-i să simtă că pot.**

**Spor!**
