# Trainer Guide — Training Web BEST Iași

**Sesiune:** 20:00 – 22:00 (cu posibilă extensie până la 22:30).
**Format:** on-site, ~17 participanți, 4–5 cu ceva experiență, restul beginneri.
**Goal:** la 22:00 fiecare participant are un site live pe URL public + materiale ca să continue singur.
**Context:** voluntariat BEST Iași — instruim studenți să construiască ei înșiși site-urile evenimentelor viitoare.

---

## Înainte de training

### Cu 24h înainte
- **Trimite `pdf/00-inainte.pdf` + folderul `starter/`** în grupul Discord/Slack.
- Postează mesajul de mai jos.
- Confirmă cu cei mai pasivi 1-1 că au făcut setup-ul.

#### Mesaj copy-paste pentru Discord/Slack

```
Sal omuleți, mâine ne vedem la 20:00 pentru training-ul de web dev.

📎 Atașat: PDF de 3 pagini cu lucrurile pe care vă rog să le instalați
ÎNAINTE de training. Durează ~15 minute total.

Pe scurt aveți de:
  1. Instalat Visual Studio Code (+ extensia Live Server)
  2. Instalat Git și configurat cu numele și emailul vostru
  3. Cont GitHub creat (gratuit)
  4. Verificat că toate funcționează (4 teste rapide în PDF)

⚠️ Vă rog făceți astea AZI, nu mâine la 19:55. Dacă ceva nu merge, dați
de mine acum și rezolvăm — e mult mai ușor așa decât în primele minute
ale training-ului.

Aduceți cu voi:
  - Laptop + încărcător
  - O idee de site dacă aveți (un portofoliu, un blog, un site BEST,
    orice — nu e obligatoriu, dar dacă aveți, e mai distractiv)
  - Răbdare. Promit că la 22:00 fiecare are un site live cu URL-ul lui.

Pe mâine! 🚀
```

#### Mesaj follow-up cu 2-3h înainte (optional)

```
Reminder: ne vedem peste câteva ore. Cine n-a făcut încă setup-ul, e
ultimul moment. Locul: [SALA].

Aduceți laptop încărcat. Wi-Fi există dar dacă aveți hotspot ca backup,
foarte ok.

Vă văd!
```

### În ziua training-ului
- **Adu cu tine:**
  - Laptop-ul tău cu tot setup-ul ready (incl. un proiect demo final pe care să-l arăți).
  - **USB stick** cu installerele pentru VS Code, Git (în caz că Wi-Fi pică).
  - **Hotspot** pe telefon ca backup pentru internet.
  - Toate PDF-urile imprimate sau pe laptop, ușor accesibile.
- **Pre-brief cei 3 avansați (Dennis, Evelina, zaco):**
  - 5 min înainte de start: *"Voi sunteți deja peste media de aici, dacă vedeți pe cineva blocat, vă rog ajutați. E cel mai bun mod să vă consolidați."*
- **Verifică sala:** prize destule, proiector funcțional, conectare internet.

---

## Schema sesiunii (2h)

| Slot | Durată | Bloc | Handout-ul deschis |
|---|---|---|---|
| 20:00 – 20:05 | 5 min | Hook & welcome | — |
| 20:05 – 20:15 | 10 min | Modelul mental + setup checkpoint | `01-introducere` |
| 20:15 – 20:35 | 20 min | **Site BTW** — HTML + CSS din template | `07-exercitiu` |
| 20:35 – 20:50 | 15 min | Personalizează site-ul tău | `07-exercitiu` + `03-css` |
| 20:50 – 20:55 | 5 min | **Pauză** | — |
| 20:55 – 21:10 | 15 min | JS — interactivitate (hamburger, formular) | `07-exercitiu` + `04-javascript` |
| 21:10 – 21:30 | 20 min | **Deploy live** — momentul magic | `05-deployment` |
| 21:30 – 21:45 | 15 min | SEO + Analytics quick walkthrough | `05-deployment` |
| 21:45 – 22:00 | 15 min | Wrap-up + Q&A + formare echipe | `06-resurse` |

**Total: 120 min, exact.** Extension de 30 min mai jos.

---

## Block 1 — Hook & welcome (20:00 – 20:05)

**Obiectiv:** energie + claritate asupra a ce se va întâmpla.

- Deschide laptop-ul, **arată un site finit** (ex: un site BEST mic pe care l-ai făcut, sau site-ul unui eveniment trecut).
- Click prin el. Apoi **deschide source code-ul în VS Code lângă**.
- Spune literal: *"Codul de pe stânga e ce vom scrie împreună. Mai puțin decât pare. La 22:00, fiecare are unul ca ăsta pe un URL real."*
- **Energy check** (mâini ridicate): *"câți nu ați scris niciodată cod de website?"* — asta îți spune unde e bara. Confirmă că suntem la nivelul potrivit.
- **Nu introduce conceptele** încă. Doar destinația.

---

## Block 2 — Modelul mental + setup checkpoint (20:05 – 20:15)

**Obiectiv:** toată sala are VS Code deschis cu un fișier care apare în browser.

### Modelul mental (3 min)
- Slide / desk drawing cu cele 3 straturi:
  - **HTML** = frame-urile din Figma (structura, ce există)
  - **CSS** = panoul de styles din Figma (cum arată)
  - **JS** = prototyping-ul din Figma (ce reacționează la click)
- 1 frază despre browser: *"browserul cere fișierul de la un server și îl desenează. Atât."*

### Setup checkpoint (7 min) — **NEGOCIABIL ZERO**
1. Toți deschid VS Code.
2. Creează folder `best-site` pe Desktop sau Documents.
3. *File → Open Folder* → alege folderul.
4. *New File* → `index.html`.
5. Scrie `<h1>hello</h1>`. **Salvează (Ctrl+S).**
6. Click dreapta pe fișier → *Open with Live Server*.
7. **Toți trebuie să vadă "hello" în browser înainte să trec mai departe.**

> 🚨 **Dacă cineva nu are VS Code sau Live Server:** dă-le un ChromeBook spare sau pune-i lângă un coleg. Nu pierde 20 min de grup pe 1 om. *Reference: handout 01-introducere.*

---

## Block 3 — HTML + CSS scheletul (20:15 – 20:35)

**Obiectiv:** fiecare are pagina **BEST Training Weekend** styled, deja cu hero, secțiuni, traineri.

> 💡 **Folosim exercițiul practic din `07-exercitiu.pdf`.** E un site complet pentru un BEST Training Weekend imaginar — exact ce o să facă ei la concurs. Le dă încredere că pot construi ceva real.

### HTML (10 min)
- Deschide **`07-exercitiu.pdf`** la **Pasul 2 (HTML-ul complet)**.
- *"Copiați tot HTML-ul în `index.html`-ul vostru. Vom înțelege bucățile imediat."*
- Salvează → vezi în Live Server. **Pagina arată urât dar are structura completă.**
- Walk-through rapid prin secțiuni: hero, despre, program, traineri, înscriere.
- **Customizare rapidă:** schimbă numele evenimentului în `<h1>`, schimbă datele.

### CSS (10 min)
- Deschide **`07-exercitiu.pdf`** la **Pasul 3 (CSS-ul complet)**.
- *"Copiați tot CSS-ul în `style.css`. Salvați. Refresh."*
- **Pagina se transformă** — hero gradient, carduri, navy + galben. Moment "wow" #1.
- **Tweak rapid:** schimbă `--primary` și `--accent` din `:root` cu paleta lor preferată.
  - *"Astea sunt variabile CSS. Schimbi într-un loc, se schimbă peste tot. La fel ca în Figma."*

> 🎯 **Checkpoint vizual:** mă plimb prin sală. Toți trebuie să aibă site BEST Training Weekend styled. *Reference: handout 07.*

---

## Block 4 — Personalizare + CSS rețete (20:35 – 20:50)

**Obiectiv:** ei să-și facă SITE-UL LOR, nu cel din PDF.

- Acum că au baza, **schimbă conținutul** să fie despre ce vor ei:
  - "Schimbați 'BEST Training Weekend' cu numele evenimentului vostru — sau lăsați-l, e ok."
  - Schimbați culorile din `:root`.
  - Adăugați un trainer suplimentar copiind un `<div class="trainer">`.
- Apoi deschide **`03-css.pdf`** la **"7 Rețete gata de copiat"** și aplică 1-2:
  - Card hover effect — adaugă efect pe carduri.
  - Sticky header — deja e în CSS, dar poți arăta cum funcționează.
- *"Voi nu trebuie să țineți minte CSS-ul. Voi trebuie să știți să găsiți rețeta și s-o aplicați. Aveți 7 rețete în handout 03 + tot template-ul în handout 07."*

> 💡 *Reference: handout 07 (template) + handout 03 (rețete pentru extindere).*

---

## 🔄 Pauză (20:50 – 20:55, 5 min)

- Apă, baie, social.
- Tu: re-energizează-te. Următorul bloc e JS, atenția lor scade.
- **Încurajează-i să se uite peste site-urile vecinilor** — comparare = motivație.

---

## Block 5 — JS taste (20:55 – 21:10)

**Obiectiv:** ei să nu se sperie de JS și să știe că au snippets gata.

- 1 slide: **Pattern-ul universal** — `select → listen → change`.
- Deschide **`04-javascript.pdf`** la **"Cum se leagă HTML, CSS și JS"** (secțiune nouă, importantă).
- Apoi **`07-exercitiu.pdf`** la **Pasul 4 (JS pentru interactivitate)**.
- *"Copiați tot JS-ul în `script.js`-ul vostru. Salvați."*
- Testează cu ei live:
  - Click pe hamburger pe ecran mic → meniul apare/dispare.
  - Click pe linkurile din meniu → smooth scroll.
  - Submit la formular → mesaj de confirmare.
- Spune: *"Aveți **12 snippets** in handout 04 + decoder de erori. Nu e nevoie să țineți minte JS. E nevoie să știți unde să căutați."*

> 💡 *Reference: handout 04 (concepte) + handout 07 Pasul 4 (JS-ul concret pentru BTW).*

---

## Block 6 — Deploy live (21:10 – 21:30)

**Obiectiv:** fiecare are un URL public pe care îl poate trimite mamei.

**Acesta e momentul-cheie al training-ului.** Energie maximă.

- Deschide **`05-deployment.pdf`** la **"Pasul 1"**.
- Live-along, încet, pas cu pas:
  1. `git init -b main` (în Git Bash, în folderul lor).
  2. `git add .`
  3. `git commit -m "primul site"`
  4. Creează repo public pe GitHub (numele = ce vor ei, fără README/gitignore).
  5. `git remote add origin URL`
  6. `git push -u origin main`
  7. Settings → Pages → Branch `main` → Save.
  8. Refresh Pages tab după 30 sec → URL apare.
- **Toți pun URL-urile lor în chat-ul Discord/Slack.**
- *"Trimite-l pe WhatsApp la cineva care să-l deschidă în următoarele 5 secunde. Asta e simțirea pe care vrem s-o țineți minte."*

### Capcane de anticipat (le-ai văzut deja în handout)
- **Repo private** → 404. Reset la public din Settings.
- **Index.html cu majusculă** → 404. Rename la `index.html`.
- **Authentication popup pe Windows** → Personal Access Token (vezi handout-ul).
- **Push lent / Pages încet** → așteaptă 1 min, dă refresh.

> 💡 *Reference: handout 05, secțiunile Pasul 1–5.*

---

## Block 7 — SEO + Analytics quick walkthrough (21:30 – 21:45)

**Obiectiv:** ei să știe ce-i așteaptă DUPĂ deploy ca să fie luați în serios.

- Deschide **`05-deployment.pdf`** la **secțiunea SEO**.
- Demo rapid pe site-ul lor:
  - Adaugă `<meta name="description" content="...">` în head.
  - Adaugă Open Graph (`og:title`, `og:description`, `og:image`).
  - Mergi pe favicon.io, fă o iconiță cu litera lor inițială, descarcă, pune în repo.
  - Push.
  - Deschide pe `https://opengraph.xyz` → "uite, link-ul tău arată acum frumos pe WhatsApp".
- **Google Analytics (3 min):**
  - *"Daca vrei sa stii cati au intrat: handout 05, sectiunea Google Analytics. 3 pași: cont, ID, paste in head. Eu personal recomand **Plausible** sau **Cloudflare Analytics** pentru simplitate și GDPR — links in handout."*
- *Nu insiști pe asta în session, e referință pentru post-training.*

> 💡 *Reference: handout 05, secțiunile SEO + Google Analytics.*

---

## Block 8 — Wrap-up & teams (21:45 – 22:00)

**Obiectiv:** ei pleacă cu sentimentul "pot face asta singur" + au pe cine să întrebe.

### Recap (3 min)
- Aratați-le live ce au la dispoziție:
  - 8 PDF-uri.
  - HTML/CSS/JS templates copy-paste.
  - 7 rețete CSS, 12 snippets JS.
  - Reference card Git.
  - SEO + Analytics complete.
- Deschide **`06-resurse.pdf`**:
  - 3 site-uri-cheie: **devdocs.io**, **moderncss.dev**, **css-tricks.com**.
  - Jocuri: **Flexbox Froggy**, **Grid Garden**, **CSS Diner** — *"30 min fiecare, vă transformă"*.
  - Inspirație: **CodePen**, **unDraw**.

### Concurs & echipe (10 min)
- *"Concursul vine în [data]. Ideile pe care le-ați scris în chestionar — Lucian cu glume BEST, Evelina cu portfolio, Ghervan cu site BEST live — toate sunt bune."*
- **Încurajează asocierea:**
  - *"Cine vrea să lucreze în echipă, ridicați mâna. Spuneți-vă ideea în 1 frază. Vedeți cu cine clickuiți."*
- Lasă 5–7 min de discuție liberă cu tine ca facilitator.

### Închidere (2 min)
- *"Aveți tot ce vă trebuie. Materialele rămân la voi pentru totdeauna. Eu sunt aici dacă vă blocați."*
- Mulțumiri.

> 💡 *Reference: handout 06.*

---

## Extension opțională (22:00 – 22:30)

Dacă energia mai există, alege 1 din astea:

### Opțiunea A — Customization challenge (15 min)
- *"Aveți 10 min. Schimbați 3 lucruri pe site-ul vostru — culoare, font, sau adăugați o secțiune. Apoi share screen 30 sec fiecare cu ce ați făcut."*
- Tu te plimbi și ajuți.

### Opțiunea B — Combo avansat (20 min)
- Adaugă pe site-ul lor:
  - Header sticky (rețeta din handout 03).
  - Dark mode toggle (snippet 2 din handout 04).
  - Open Graph cu imagine (din handout 05).
- Push, vezi pe live, share linkurile.

### Opțiunea C — Q&A liber (15-30 min)
- Open mic.
- Fiecare zice unde s-a blocat sau ce vrea să facă pentru concurs.
- Tu răspunzi sau le arăți unde să caute.

---

## Energy management

- **Sala se va aglomera la 21:00.** După un slot de 30 min de cod, atenția scade.
- **Pauza la 20:50** e strategică — vine după CSS rețete (sentiment de progres) și înainte de JS (subiect mai greu).
- **Deploy-ul la 21:10–21:30** e dopamine peak — folosește-l ca să relansezi atenția.
- **Vorbește mai tare după 21:00.** Plimbă-te prin sală. Privire directă.

---

## Când cineva pică în spate

- **Pre-emptiv:** ai trio-ul Dennis/Evelina/zaco brifați (vezi pre-training).
- **Backup files:** ai pe USB un `index.html` și `style.css` deja completate. Dacă cineva e cu 15 min în spate, dă-le să le copieze și să continue de acolo.
- **Nu opri grupul.** Lasă cei 1-2 rămași în urmă să recupereze cu ajutor 1-1.

## Când ceva pică în direct

| Eroare | Soluție rapidă |
|---|---|
| VS Code nu e instalat | CodeSandbox.io ca backup, web-only |
| Live Server nu pornește | Dublu-click pe `index.html` (deschide în browser direct) |
| `git push` cere parolă, nimic nu merge | Personal Access Token, vezi handout 05 |
| GitHub Pages 404 | Așteaptă 60 sec, refresh, verifică `index.html` lowercase |
| Wi-Fi pică | Hotspot-ul tău de backup |
| Proiector pică | Toți se uită pe ecranele lor + vorbește mai tare |

---

## Ce înseamnă "succes" la 22:00

| Nivel | Definiție |
|---|---|
| **Minimum** | Toți au VS Code deschis cu un `index.html` styled și funcțional pe local. |
| **Target** | 75%+ au URL public pe GitHub Pages. |
| **Stretch** | Cineva are SEO sau analytics pus deja. |

Indiferent unde ajung, **toți pleacă cu materialele complete**. Restul se face acasă.

---

## După training

- **Postează în grup** un mesaj cu URL-urile celor care le-au făcut publice → social proof + competiție prietenoasă.
- **Întreabă peste 3 zile** cine se mai joacă cu site-ul, cine are întrebări.
- **La concurs:** asigură-te că au acces la PDF-uri (le-ai distribuit deja).

---

## Note pentru tine ca trainer

- **Nu predai facultate.** Ești coleg care arată o mecanică. Tonul: relaxat, glumeț, încurajator.
- **Greșelile sunt material didactic.** Dacă ai un typo, nu-l ascunzi — îl arăți cum îl găsești în DevTools.
- **Nu acoperi tot.** Acoperi *destul* ca ei să poată continua. Materialele fac restul.
- **BEST Iași long game:** ăsta nu e un singur eveniment. Speranța e ca peste 1–2 ani, ei să țină training-ul ăsta pentru noua generație. **Lasă-i să simtă că pot.**

**Spor!**
