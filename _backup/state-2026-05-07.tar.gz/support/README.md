# Training Web — Materiale

Handout-uri în LaTeX + ghid de trainer pentru un training de 2 ore (cu posibilă extensie 30 min) de programare web pentru începători. Audiență BEST Iași — voluntariat de mentorat student-la-student.

> **🚀 Pentru trainer:** vezi **[TRAINER_GUIDE.md](TRAINER_GUIDE.md)** pentru schema minute-cu-minute a sesiunii 20:00–22:00 cu referințe la PDF-urile de distribuit.

## Structura folderului

```
training/
├── build.sh          # script principal de compilare (Bash / Git Bash)
├── build.bat         # wrapper pentru a rula build.sh din Windows Explorer
├── README.md
├── src/              # toate fișierele .tex
│   ├── preamble.tex
│   ├── 00-inainte.tex
│   ├── 01-introducere.tex
│   ├── ...
│   └── main.tex
├── pdf/              # toate PDF-urile compilate
│   ├── 00-inainte.pdf
│   └── ...
└── starter/          # mini-template HTML/CSS/JS pentru participanți
    ├── index.html
    ├── style.css
    ├── script.js
    └── README.md
```

## Cum compilezi

### Cea mai simplă cale

Din Git Bash (sau orice terminal bash, în root-ul `training/`):

```bash
./build.sh
```

Sau, pe Windows, dublu-click pe `build.bat`.

Scriptul:
- Recompilează **toate** fișierele `.tex` din `src/`.
- Pune PDF-urile în `pdf/` (suprascrie versiunile vechi).
- Curăță fișierele auxiliare (`.aux`, `.log`, `.out`, `.toc`, `.synctex.gz`).
- Rulează `pdflatex` de două ori per fișier (pentru cross-references și outline-uri corecte).

### Compilare doar a unui fișier

```bash
./build.sh 03-css
```

Util când lucrezi la o singură secțiune și vrei iterare rapidă.

### Cu Overleaf

1. Creează un proiect nou.
2. Urcă tot ce e din `src/`.
3. Setează `main.tex` ca fișier principal pentru documentul combinat, sau oricare altul pentru secțiunile individuale.

### Cu VS Code (extensia LaTeX Workshop)

1. Instalează **LaTeX Workshop**.
2. Deschide folderul `src/`.
3. Deschide oricare `.tex` și apasă **Ctrl+Alt+B**.

## Fișierele

| Fișier | Conținut | Durată în training |
|---|---|---|
| `00-inainte.tex` | Setup înainte de training (VS Code + Live Server, Git, GitHub, test rapid) | trimis cu 24h înainte |
| `01-introducere.tex` | Modelul mental, primul Hello World, DevTools | 0:00–0:35 |
| `02-html.tex` | Tag-uri, structură, HTML semantic, exercițiu landing page | 0:35–1:05 |
| `03-css.tex` | Selectori, box model (cu diagramă TikZ), flexbox, responsive | 1:15–1:55 |
| `04-javascript.tex` | Pattern-ul select-listen-change, 3 exemple progresive | 2:05–2:25 |
| `05-deployment.tex` | git init → GitHub Pages → URL live | 2:25–2:50 |
| `06-resurse.tex` | Resurse curate, jocuri, sfaturi concurs, checklist | 2:50–3:00 |
| `main.tex` | Pagină de titlu și hartă a pachetului |

## Stilul vizual

Fiecare parte are propria culoare distinctă, ca să fie ușor de identificat:

- **Pre-rechizite** — slate gri
- **Partea 1: Intro** — albastru
- **Partea 2: HTML** — portocaliu HTML5
- **Partea 3: CSS** — magenta
- **Partea 4: JS** — auriu
- **Partea 5: Deployment** — verde
- **Partea 6: Resurse** — violet

Cutiile colorate au înțelesuri consistente:

- **Galben (Notă)** — context util
- **Albastru (Pont)** — sfat practic, scurtătură
- **Roșu (Atenție)** — capcane comune
- **Portocaliu (Joc)** — exercițiu interactiv (Flexbox Froggy etc.)
- **Roz (Știai că?)** — curiozitate / fun fact
- **Verde (Recap)** — sumar
- **Mov (Exercițiu)** — mini-task

## Filozofia resurselor

Materialul de training e o punte de intrare. Pentru aprofundare, `06-resurse.tex` îi trimite spre 3 site-uri triate:

- **devdocs.io** — referință zilnică, funcționează și offline.
- **moderncss.dev** — articole moderne, scurte, practice (lista curată).
- **css-tricks.com** — *A Complete Guide to Flexbox* și *A Complete Guide to Grid* sunt obligatorii la favorite.

Plus jocuri (Flexbox Froggy, Grid Garden, CSS Diner — fiecare ~30 min), resurse vizuale (unDraw, Heroicons, Codepen) și o mențiune finală despre refactoring.guru pentru când vor scrie cod „pe bune".

## Distribuire

- Trimite `00-inainte.pdf` + folderul `starter/` cu cel puțin 24h înainte de training.
- Printează (sau distribuie digital) fișierele 01–06 ca **suport în timpul training-ului**.
- După training, fișierele rămân ca referință.

## Adaptări

- **Schimbi limba** → totul e în română. Pentru engleză, ai de tradus body-text-ul (codul rămâne identic).
- **Tai JavaScript** dacă ai doar 2h → omite `04-javascript.tex` și treci direct la deployment.
- **Adaugi conținut** → fiecare secțiune e un fișier separat, deci poți insera unul nou între oricare două (ex: `03b-grid.tex`) fără să strici nimic — adaugă-l și în `FILES=( ... )` din `build.sh`.
- **Branding BEST** → la `\handout{...}{...}` și în footer-ul din `preamble.tex` (`\fancyhead[L]`).

## Cerințe

- **MiKTeX** sau **TeX Live** (pentru `pdflatex`).
- Pe Windows: **Git for Windows** (pentru `bash` în `build.bat`).
- Pachete LaTeX folosite (toate sunt standard, MiKTeX le auto-instalează la prima rulare): `babel`, `geometry`, `xcolor`, `listings`, `hyperref`, `enumitem`, `titlesec`, `fancyhdr`, `parskip`, `tcolorbox`, `tikz`, `tocloft`.
