# Starter — site nou in 3 fisiere

Cele 3 fisiere care fac un site:

- `index.html` — **structura** (ce exista pe pagina)
- `style.css` — **stilul** (cum arata)
- `script.js` — **comportamentul** (ce face cand dai click)

## Cum pornesti

1. Deschide folderul in VS Code (`File → Open Folder`).
2. Click dreapta pe `index.html` → **Open with Live Server**.
3. Modifica orice. Salveaza. Browser-ul se reincarca singur.

## 3 idei sa-l faci al tau (5 minute)

1. **Schimba culorile** — in `style.css`, primele 4 linii (`--primary`, `--accent`...).
2. **Schimba textul** — in `index.html`, ce e intre `<h1>` si `<p>`.
3. **Schimba mesajele** — in `script.js`, lista `messages`.

Cand esti multumit: vezi handout-ul **05-deployment.pdf** ca sa-l pui live pe URL public.
