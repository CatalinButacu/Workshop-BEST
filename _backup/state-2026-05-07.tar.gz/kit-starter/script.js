const btn = document.getElementById('magic');
const messages = ['Bravo!', 'Inca o data!', 'Mai!', 'Te descurci!', 'Inapoi la cod.'];
let i = 0;

btn.addEventListener('click', () => {
  btn.textContent = messages[i % messages.length];
  const hue = Math.floor(Math.random() * 360);
  document.body.style.background = `hsl(${hue}, 60%, 95%)`;
  i++;
});
